<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="../assets/img/favicon.ico">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Tutorial Components - Light Bootstrap Dashboard Pro by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>
    <link href="../assets/css/demo.css" rel="stylesheet" />

    <link rel="stylesheet" type="text/css" href="https://cdn.rawgit.com/google/code-prettify/master/loader/prettify.css">
    <link href="css/documentation.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Grand+Hotel|Open+Sans:400,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
</head>

<body>



<div class="header-wrapper">
        <nav class="navbar navbar-transparent navbar-fixed-top" role="navigation" color-on-scroll>
          <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              <button id="menu-toggle" type="button" class="navbar-toggle">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar bar1"></span>
                <span class="icon-bar bar2"></span>
                <span class="icon-bar bar3"></span>
              </button>
              <a href="http://www.creative-tim.com">
                   <div class="logo-container">
                        <div class="logo">
                            <img src="../assets/img/new_logo.png" alt="Creative Tim Logo">
                        </div>
                        <div class="brand">
                            Creative Tim
                        </div>
                    </div>
              </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse">
              <ul  class="nav navbar-nav navbar-right">
                    <li>
                        <a href='https://github.com/creativetimofficial/light-bootstrap-dashboard/issues' target="_blank" id="issueButton" class="btn btn-simple btn-neutral">Have an issue?</a>
                    </li>
               </ul>

            </div><!-- /.navbar-collapse -->
          </div><!-- /.container-fluid -->
        </nav>

        <div class="header" style="background-image: url('../assets/img/full-screen-image-3.jpg');
">
            <div class="filter"></div>
            <div class="title-container text-center">
                    <h1>Light Bootstrap Dashboard</h1>
                    <h3 class="category">v1.4.0</h3>
                    <h4 class="description text-center">We are constantly doing updates for you.</h4>
                    <a href="http://demos.creative-tim.com/light-bootstrap-dashboard/documentation/tutorial-components.html" class="btn btn-neutral btn-lg btn-round btn-fill" target="_blank">View Documentation</a>
            </div>
        </div>
</div>




<footer class="footer footer-demo">
	<div class="container">
		<nav class="pull-left">
			<ul>
				<li>
					<a href="http://www.creative-tim.com/product/light-bootstrap-dashboard">
						Light Bootstrap Dashboard
					</a>
				</li>
				<li>
					<a href="http://www.creative-tim.com">
						Creative Tim
					</a>
				</li>
				<li>
					<a href="http://blog.creative-tim.com">
					   Blog
					</a>
				</li>
			</ul>
		</nav>
		<div class="social-area pull-right">
			<a class="btn btn-social btn-twitter btn-simple" href="https://twitter.com/CreativeTim">
				<i class="fa fa-twitter"></i>
			</a>
			<a class="btn btn-social btn-facebook btn-simple" href="https://www.facebook.com/CreativeTim">
				<i class="fa fa-facebook-square"></i>
			</a>
			<a class="btn btn-social btn-google btn-simple" href="https://plus.google.com/+CreativetimPage">
				<i class="fa fa-google-plus"></i>
			</a>
		</div>
		<div class="copyright">
			&copy; <script>document.write(new Date().getFullYear())</script> Creative Tim, made with love
		</div>
	</div>
</footer>
</body>
	<!--   Core JS Files   -->
	<script src="../assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

	<!--  Notifications Plugin    -->
	<script src="../assets/js/bootstrap-notify.js"></script>

	<!--  Google Maps Plugin    -->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

	<!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="../assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>
</html>
