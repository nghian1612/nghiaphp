<?php
require_once 'pdo.php';


function khachhang_insert($matkhau, $ten_kh, $email){
    $sql = "INSERT INTO khachhang(matkhau,ten_kh,email) VALUES(?,?,?)";
    pdo_execute($sql, $matkhau, $ten_kh, $email);
}



function khachhang_update($ma_kh, $matkhau, $ten_kh, $email){
    $sql = "UPDATE khachhang SET khachhang=? WHERE ma_kh=?";
    pdo_execute($sql, $matkhau, $ten_kh, $email);
}


function khachhang_delete($ma_kh){
    $sql = "DELETE FROM khachhang WHERE ma_kh=?";
    if(is_array($ma_kh)){
        foreach ($ma_kh as $ma) {
            pdo_execute($sql, $ma);
        }
    }
    else{
        pdo_execute($sql, $ma_kh);
    }
}



function khachhang_select_all(){
    $sql = "SELECT * FROM khachhang ORDER BY ma_kh DESC";
    return pdo_query($sql);
}



function khachhang_select_by_id($ma_kh){
    $sql = "SELECT * FROM khachhang WHERE ma_kh=?";
    return pdo_query_one($sql, $ma_kh);
}


function khachhang_exist($ma_kh){
    $sql = "SELECT count(*) FROM khachhang WHERE ma_kh=?";
    return pdo_query_value($sql, $ma_kh) > 0;
}


